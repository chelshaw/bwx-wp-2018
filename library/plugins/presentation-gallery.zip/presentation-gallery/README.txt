=== Presentation Gallery ===
Contributors: chelseashaw
Tags: gallery, viewer, filmstrip
Requires at least: 2.8
Tested up to: 4.9
Stable tag: 1.0.0

Optional modification to the gallery shortcode that allows clickable thumbnails which update the main viewer.

== Description ==

Adds a main view above the thumbnails, which switches to whichever image was clicked in the main viewer. Works best with large version of images selected, and no link.

**Usage**

Insert gallery as normal, and add `present=1` to the shortcode.

*Example :*

`[gallery present=1 link="none" columns="4" size="large" ids="104,27,26,25"]`

== Installation ==

To install the plugin follow these steps :

1. Download the presentation-gallery.zip file to your local machine.
1. Go to 'Plugins -> Add New -> Upload'.
1. Upload the zip file using the provided form.
1. Activate the plugin through the 'Plugins' menu in WordPress

Alternatively, you can search for "Presentation Gallery" in 'Plugins -> Add New -> Search' and install it from there, or unzip presentation-gallery.zip and upload the `presentation-gallery` directory to your `/wp-content/plugins` directory.
