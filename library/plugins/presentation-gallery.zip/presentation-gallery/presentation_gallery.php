<?php
/*
Plugin Name: Presentation Gallery
Description: Optional modification to the gallery shortcode that allows clickable thumbnails which update the main viewer.
Version: 1.0.0
Author: Chelsea Shaw
Author URI: https://github.com/chelshaw
*/

define('PRESENTATION_GALLERY_PLUGIN_FILE', __FILE__);

require 'include/gallery_override.php';

if ( is_admin() && file_exists(dirname(__FILE__).'/editor-plugin/init.php') ){
	require dirname(__FILE__) . '/editor-plugin/init.php';
}
