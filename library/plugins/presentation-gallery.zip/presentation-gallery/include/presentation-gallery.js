(function($){
  $('.presgal__gallery-item').click(function(){
  	$('#presgal__image-viewer').attr('src',$(this).find('img').attr('src'));
  	$('#presgal__image-description').text($(this).find('img').attr('alt'));
  });

  function initiateGallery() {
    const display = $('#presgal__image-viewer');
    if (!display) return;
    const first = $('.gallery').children('.presgal__gallery-item').first();
    display.attr('src', first.find('img').attr('src'));
    $('#presgal__image-description').text(first.find('img').attr('alt'));
  }
  initiateGallery();
})(jQuery);
